# PulseUp Android

WebView-обёртка сайта https://pulseup0.github.io/PulseUp/
Сборка: Actions → Build APK → Run workflow → Artifacts → PulseUp-apk.
